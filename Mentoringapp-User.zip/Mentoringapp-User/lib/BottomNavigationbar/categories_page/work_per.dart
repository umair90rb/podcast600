import 'package:flutter/material.dart';

class WorkAndProfesstion extends StatefulWidget {
  WorkAndProfesstion({Key key}) : super(key: key);

  @override
  _WorkAndProfesstionState createState() => _WorkAndProfesstionState();
}

class _WorkAndProfesstionState extends State<WorkAndProfesstion> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("WorkAndProfesstion page"),
      ),
    ); 
  }
}